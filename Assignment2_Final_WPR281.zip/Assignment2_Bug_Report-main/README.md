# Assignment2_Bug_Report

1. Okay so a button has been created on the project dashbaord side for the tickets to be linked to. 
2. Myself and Devlyn are busy trying to search and sort the projects.
3. Then we also need to do the login page, but thats small things.
